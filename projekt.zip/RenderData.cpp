#include "RenderData.h"



RenderData::RenderData()
{
}


RenderData::~RenderData()
{
}
