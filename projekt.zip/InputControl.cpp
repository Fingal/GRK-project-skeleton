#include "InputControl.h"



InputControl::InputControl()
{
}


InputControl::~InputControl()
{
}
