#pragma once
#include "RenderObject.h"

class Terrain :
	public RenderObject
{
public:
	Terrain();
	~Terrain();
	glm::mat4 calculateTransformationMarix(float time);

	float getHeight(float x, float y);

	void render(RenderData data);

	void init();

private:


	int size;

	GLuint program;
	GLuint vertexArray;
	GLuint vertexBuffer;
	GLuint vertexIndexBuffer;
};

