#pragma once
#include "glew.h"
#include "glm.hpp"
#include "ext.hpp"
class RenderData
{
public:
	glm::mat4 cameraProjectionMatrix;
	glm::vec3 lightSource;
	RenderData();
	~RenderData();
};

