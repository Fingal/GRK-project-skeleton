#pragma once
#include <map>
#include "glew.h"
#include "glm.hpp"
#include "ext.hpp"
#include "InputControl.h"
#include "Camera.h"
#include "SceneGraphNode.h"
#include "RenderObject.h"
#include "freeglut.h"
#include "RenderData.h"

using namespace std;
class Scene
{
public:
	Scene();
	~Scene();
	int registerObject(RenderObject* object);
	int registerInput(InputControl* input);

	void removeObject(int id);
	void removeInput(int id);

	void calculateMatrices(float time);

	void keyboard(unsigned char key, int x, int y);

	void mouse(int button, int state, int x, int y);
	void setLight(glm::vec3 light);
	glm::vec3 setLight();
	void render();

	void setCamera(Camera* camera);


private:
	map<unsigned int,InputControl*> inputControls;
	map<unsigned int, RenderObject*> renderObjects;
	Camera* camera;
	unsigned int lastIdObjects;
	unsigned int lastIdInput;
	glm::vec3 light;
};

